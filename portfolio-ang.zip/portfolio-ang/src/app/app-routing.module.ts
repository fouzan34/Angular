import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AwardComponent } from './components/award/award.component';
import { EducationComponent } from './components/education/education.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { SkillsComponent } from './components/skills/skills.component';
import { AboutmeComponent } from './components/aboutme/aboutme.component';
import { ContactComponent } from './components/contact/contact.component';


const routes: Routes = [
  {path:'award', component:AwardComponent},
  {path:'education', component:EducationComponent},
  {path:'experience', component:ExperienceComponent},
  {path:'skills', component:SkillsComponent},
  {path:'contact', component:ContactComponent},
  {path:'aboutme', component:AboutmeComponent},
  {path:'', redirectTo:'aboutme', pathMatch:'full'}
 // {path:'', redirectTo:'award',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
